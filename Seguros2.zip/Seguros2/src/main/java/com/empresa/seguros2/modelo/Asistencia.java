package com.empresa.seguros2.modelo;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Time;
import java.util.Date;


/**
 * The persistent class for the asistencia database table.
 * 
 */
@Entity
@Table(name="asistencia")
@NamedQuery(name="Asistencia.findAll", query="SELECT a FROM Asistencia a")
public class Asistencia implements Serializable {
	private static final long serialVersionUID = 1L;

	enum Tipo {Hospitalaria, Ambulatoria, Domiciliaria, CentroSalud}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String descripcion;

	@Column(length=300)
	private byte[] explicacion;

	@Temporal(TemporalType.DATE)
	private Date fecha;

	private Time hora;

	private BigDecimal importe;

	private String lugar;

	private Tipo tipoAsistencia;

	//bi-directional many-to-one association to Seguro
	@ManyToOne
	@JoinColumn(name="seguroId")
	private Seguro seguro;

	public Asistencia() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public byte[] getExplicacion() {
		return this.explicacion;
	}

	public void setExplicacion(byte[] explicacion) {
		this.explicacion = explicacion;
	}

	public Date getFecha() {
		return this.fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Time getHora() {
		return this.hora;
	}

	public void setHora(Time hora) {
		this.hora = hora;
	}

	public BigDecimal getImporte() {
		return this.importe;
	}

	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}

	public String getLugar() {
		return this.lugar;
	}

	public void setLugar(String lugar) {
		this.lugar = lugar;
	}

	public Tipo gettipoAsistencia() {
		return this.tipoAsistencia;
	}

	public void setTipoAsistencia(Tipo tipoAsistencia) {
		this.tipoAsistencia = tipoAsistencia;
	}

	public Seguro getSeguro() {
		return this.seguro;
	}

	public void setSeguro(Seguro seguro) {
		this.seguro = seguro;
	}

}