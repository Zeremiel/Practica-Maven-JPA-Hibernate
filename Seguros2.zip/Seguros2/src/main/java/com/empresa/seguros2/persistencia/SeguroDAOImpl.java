package com.empresa.seguros2.persistencia;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.empresa.seguros2.modelo.Seguro;
public class SeguroDAOImpl extends GenericDAOImplJpa<Seguro, Integer> implements SeguroDAO
{
public List<Seguro> findByNombre()
	{
	EntityManager em = Utilidades.getEntityManagerFactory().createEntityManager();
	TypedQuery<Seguro> q = em.createQuery(
			" select e "
			+ "from Seguro e "
					+ "where e.id = :id ", Seguro.class);
	q.setParameter(0, "id");	
	return q.getResultList();
	
	}
}
