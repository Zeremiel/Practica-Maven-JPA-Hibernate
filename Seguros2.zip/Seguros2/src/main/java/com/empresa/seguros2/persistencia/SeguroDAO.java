package com.empresa.seguros2.persistencia;

import com.empresa.seguros2.modelo.Seguro;

public interface SeguroDAO extends GenericDAO<Seguro, Integer>   {

}
