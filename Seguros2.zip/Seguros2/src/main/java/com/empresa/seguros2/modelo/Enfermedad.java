package com.empresa.seguros2.modelo;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the enfermedad database table.
 * 
 */
@Converter(autoApply = true)
@Entity
@Table(name="enfermedad")
@NamedQuery(name="Enfermedad.findAll", query="SELECT e FROM Enfermedad e")
public class Enfermedad implements Serializable {
	private static final long serialVersionUID = 1L;

	public Character convertToDatabaseColumn(Boolean attribute) {
        if (attribute != null) {
            if (attribute) {
                return 'Y';
            } else {
                return 'N';
            }
                 
        }
        return null;
    }
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private boolean alergia;

	private boolean corazon;

	private boolean estomacal;

	private String nombreAlergia;

	private boolean rinyones;

	public Enfermedad() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public boolean getAlergia() {
		return this.alergia;
	}

	public void setAlergia(boolean alergia) {
		this.alergia = alergia;
	}

	public boolean getCorazon() {
		return this.corazon;
	}

	public void setCorazon(boolean corazon) {
		this.corazon = corazon;
	}

	public boolean getEstomacal() {
		return this.estomacal;
	}

	public void setEstomacal(boolean estomacal) {
		this.estomacal = estomacal;
	}

	public String getNombreAlergia() {
		return this.nombreAlergia;
	}

	public void setNombreAlergia(String nombreAlergia) {
		this.nombreAlergia = nombreAlergia;
	}

	public boolean getRinyones() {
		return this.rinyones;
	}

	public void setRinyones(boolean rinyones) {
		this.rinyones = rinyones;
	}

}