package com.empresa.seguros2;

import java.util.List;


import com.empresa.seguros2.modelo.Seguro;
import com.empresa.seguros2.persistencia.SeguroDAO;
import com.empresa.seguros2.persistencia.SeguroDAOImpl;

public class SeguroControlador {

		SeguroDAO seguroDAO;
		
		public SeguroControlador()
		{
			seguroDAO =  new SeguroDAOImpl();
			
		}
		
		public void ej1() 
		{
			List<Seguro> seguros = seguroDAO.findById(5);
			for (Seguro s: seguros)
			{System.out.println(s.toString());
				
			}
		}
		
}
