package com.empresa.seguros2;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.persistence.EntityManager;

import com.empresa.seguros2.modelo.Seguro;
import com.empresa.seguros2.persistencia.Utilidades;



/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		EntityManager em = null;

		try {
			em = Utilidades.getEntityManagerFactory().createEntityManager();
			SeguroControlador sc = new SeguroControlador();
			
//			
			

		} catch (Exception e) {
			if (em != null) {
				e.printStackTrace();
				System.out.println("Se va a hacer rollback de la transacción");
				em.getTransaction().rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		Utilidades.closeEntityManagerFactory();
	}
}
